var user: object = { name: "shiva", age: 10 };

console.log(user);
console.log(user.email);

var id: number = 5555;
var id: string = "hhh";

var a;
