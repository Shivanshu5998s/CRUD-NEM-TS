let user = { name: "shiva", age: 10 };

console.log("object");
console.log(user.email);
